/* ═════════════════════════════════════════════════════════════════
   MOLEFIELD · safety.js
   OWNER: PERSON 4
   SUBSYSTEM: Dead-zone supervisor & warning HMI

   CONSUMES  Tracker.pos, Tracker.stale — nothing else, deliberately
   PROVIDES  Safety.active (bool) · Safety.update(dt) · Safety.reset()

   Nobody else edits this file. If you need it to behave differently,
   ask the owner — that conversation is what your change register is made of.

   YOUR NUMBER: Alarm latency from crossing 0.60 m (ms) and false-alarm rate
                over a 10-minute session.
   ═════════════════════════════════════════════════════════════════ */
"use strict";

/* This runs every frame regardless of what the game is doing — while paused,
   between levels, sitting on the menu. A guard that only works during normal
   operation is not a guard. Keep it that way; it is the single easiest thing
   in this project to argue for at the review, and the easiest to quietly
   break by moving it inside an `if (playing)`. */

const Safety = {
  active: false,      // alarm currently sounding
  since: 0,           // seconds the body has been past the line
  clearFor: 0,        // seconds it has been back in the clear
  onDelay: 0.00,      // hold-on time before the alarm fires   (see notes)
  offDelay: 0.25,     // hold-off time before it stops         (hysteresis)
  breaches: 0,        // count for the test log

  /** True when the tracked body is closer to the wall than the play area. */
  breached() {
    return !!(Tracker.pos && !Tracker.stale && Tracker.pos.y < AREA.yNear);
  },

  update(dt) {
    const bad = this.breached();

    if (bad) { this.since += dt; this.clearFor = 0; }
    else     { this.clearFor += dt; this.since = 0; }

    /* Hysteresis: fire quickly, release slowly. Without the release delay a
       body hovering on the line makes the alarm stutter on and off, which
       reads as a fault rather than a warning. Without a fast attack you are
       telling someone they are about to hit a screen after they already have.
       These two numbers are yours to justify with measurements. */
    const want = bad ? this.since >= this.onDelay
                     : !(this.clearFor >= this.offDelay);

    if (want !== this.active) {
      this.active = want;
      if (want) this.breaches++;
      dz.classList.toggle("on", want);
      want ? Audio_.alarmOn() : Audio_.alarmOff();
    }
  },

  /** Called on pause, level change and game over. Silences without pretending
      the body has moved — the next update() re-evaluates from live data. */
  reset() {
    this.active = false;
    this.since = this.clearFor = 0;
    dz.classList.remove("on");
    Audio_.alarmOff();
  },

  /* ── Where to take this for V2 ──────────────────────────────────────────
     Right now the alarm fires when the body has already crossed the line.
     A person walking at 1.2 m/s covers 300 mm in the time it takes to react.
     Extrapolate: if (pos.y - velocity * lookahead) < yNear, warn early.
     Tracker.pos gives you position each frame — differentiate it, and be
     honest about how noisy that derivative is before you trust it.
     Measure both versions and put the pair of numbers in your change log. */
};
