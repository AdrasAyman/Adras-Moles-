/* ═════════════════════════════════════════════════════════════════
   MOLEFIELD · game.js
   OWNER: PERSON 3
   SUBSYSTEM: Game logic, levels & difficulty

   CONSUMES  Tracker.pos and Tracker.stale · LEVELS from core.js
   PROVIDES  G (game state) · updateGame(dt) · resetRun() · startLevel(i) · spawn() · hit(m)

   Nobody else edits this file. If you need it to behave differently,
   ask the owner — that conversation is what your change register is made of.

   YOUR NUMBER: Hit rate and median time-to-whack per level, from playtest logs
   ═════════════════════════════════════════════════════════════════ */
"use strict";

/* ── Game state ──────────────────────────────────────────────── */
const G = {
  phase:"start",         // start | play | levelup | over | pause
  li:0, score:0, streak:1, missed:0, hitsThisLevel:0,
  t:0, holes:[], moles:[], fx:[], dwell:0, dwellTarget:null,
  totalHits:0, totalShown:0, bestStreak:1
};

function buildHoles(){
  const L = LEVELS[G.li];
  G.holes = [];
  const mx = 0.16, my = 0.16;            // margin in normalised play-field units
  for(let r=0;r<L.rows;r++) for(let c=0;c<L.cols;c++){
    const u = L.cols===1 ? .5 : mx + (c/(L.cols-1))*(1-2*mx);
    const v = L.rows===1 ? .5 : my + (r/(L.rows-1))*(1-2*my);
    G.holes.push({
      u, v,
      x: u*AREA.w,
      y: AREA.yNear + v*AREA.deep,
      occupied:null
    });
  }
}

function startLevel(i){
  G.li = i; G.t = LEVELS[i].dur; G.hitsThisLevel = 0;
  G.moles = []; G.fx = []; G.dwell = 0; G.dwellTarget = null;
  buildHoles();
  G.phase = "play";
  spawn();
}

function resetRun(){
  G.score=0; G.streak=1; G.missed=0; G.totalHits=0; G.totalShown=0; G.bestStreak=1;
  startLevel(0);
}

function spawn(){
  const L = LEVELS[G.li];
  const free = G.holes.filter(h=>!h.occupied);
  if(!free.length) return;
  const h = free[(Math.random()*free.length)|0];
  let kind = "mole";
  const roll = Math.random();
  if(L.bombs && roll < 0.16) kind = "bomb";
  else if(L.gold && roll < 0.28) kind = "gold";
  const m = {
    hole:h, kind,
    life: L.life * (kind==="gold" ? 0.8 : 1) * (0.85 + Math.random()*0.3),
    age:0, state:"rise", pop:0, dwell:0, dead:false
  };
  h.occupied = m; G.moles.push(m);
  if(kind !== "bomb") G.totalShown++;
}

function hit(m){
  const L = LEVELS[G.li];
  if(m.kind === "bomb"){
    G.score = Math.max(0, G.score - 15);
    G.streak = 1;
    Audio_.bomb();
    G.fx.push({type:"burst", x:m.hole.x, y:m.hole.y, t:0, col:"#FF4D3D", text:"−15"});
    shake = 0.35;
  } else {
    const base = m.kind === "gold" ? 30 : 10;
    const pts = base * G.streak;
    G.score += pts;
    G.hitsThisLevel++; G.totalHits++;
    G.streak = Math.min(8, G.streak + 1);
    G.bestStreak = Math.max(G.bestStreak, G.streak);
    m.kind === "gold" ? Audio_.gold() : Audio_.whack();
    G.fx.push({type:"burst", x:m.hole.x, y:m.hole.y, t:0,
               col: m.kind==="gold" ? "#FFB020" : "#9BE86B", text:"+"+pts});
  }
  m.dead = true; m.state = "hit";
  if(G.hitsThisLevel >= L.target) levelComplete();
}

function levelComplete(){
  if(G.li >= LEVELS.length-1){ endRun("You cleared every level"); return; }
  G.phase = "levelup";
  Audio_.level(); Safety.reset();
  const nx = LEVELS[G.li+1];
  $("#lvBig").textContent = nx.n;
  $("#lvName").textContent = nx.name;
  $("#lvDesc").textContent = nx.desc;
  show("#ovLevel");
}

function endRun(title){
  G.phase = "over";
  Audio_.over(); Safety.reset();
  $("#endTitle").textContent = title;
  $("#endScore").textContent = G.score;
  const acc = G.totalShown ? Math.round(100*G.totalHits/G.totalShown) : 0;
  $("#endStats").textContent =
    `Level ${LEVELS[G.li].n} · ${G.totalHits} whacked · ${acc}% of moles caught · best streak ×${G.bestStreak}`;
  show("#ovEnd");
}

/* ── Per-frame game update ───────────────────────────────────────────────
   Called by main.js only while phase === "play". Everything here is about
   moles, timing and scoring. Dead-zone supervision deliberately does NOT
   live in this function — see safety.js for why. */
function updateGame(dt){
  const L = LEVELS[G.li];
  G.t -= dt;
  if(G.t <= 0){ G.t = 0; endRun("Time"); return; }

  // mole lifecycle: rise → up → sink (or hit)
  for(const m of G.moles){
    m.age += dt;
    if(m.state === "rise"){ m.pop = Math.min(1, m.pop + dt*7); if(m.pop>=1) m.state="up"; }
    else if(m.state === "up"){
      if(m.age > m.life) m.state = "sink";
    } else if(m.state === "sink" || m.state === "hit"){
      m.pop -= dt * (m.state==="hit" ? 12 : 5);
      if(m.pop <= 0){
        m.pop = 0; m.hole.occupied = null; m.gone = true;
        if(m.state === "sink" && m.kind !== "bomb"){
          G.missed++; G.streak = 1; Audio_.escaped();
        }
      }
    }
  }

  /* Dwell-to-whack. There is no button, so a whack is holding your body over
     a mole for L.dwell seconds. Only the nearest mole inside `grab` charges;
     everything else decays, so brushing past a mole on the way to another one
     does not bank progress you did not earn. */
  const canPlay = Tracker.pos && !Safety.active && !Tracker.stale;
  let target = null;
  if(canPlay){
    let bestD = Infinity;
    const grab = 0.17;   // metres — how close your body centre must be
    for(const m of G.moles){
      if(m.dead || m.state==="sink") continue;
      const d = Math.hypot(Tracker.pos.x - m.hole.x, Tracker.pos.y - m.hole.y);
      if(d < grab && d < bestD){ bestD = d; target = m; }
    }
  }
  for(const m of G.moles) if(m !== target) m.dwell = Math.max(0, m.dwell - dt*2.5);
  if(target){
    target.dwell += dt;
    if(target.dwell >= L.dwell) hit(target);
  }

  G.moles = G.moles.filter(m=>!m.gone);
  const live = G.moles.filter(m=>m.state!=="sink" && !m.dead).length;
  if(live < L.max && Math.random() < dt*2.2) spawn();
  if(live === 0 && G.moles.length === 0) spawn();

  for(const f of G.fx) f.t += dt;
  G.fx = G.fx.filter(f=>f.t < 0.6);
}
