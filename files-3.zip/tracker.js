/* ═════════════════════════════════════════════════════════════════
   MOLEFIELD · tracker.js
   OWNER: PERSON 2
   SUBSYSTEM: Signal conditioning, input sources & latency

   CONSUMES  solvePosition() from solver.js; ranges from mouse, simulation or WebSocket
   PROVIDES  Tracker.pos {x,y} smoothed · Tracker.raw unfiltered · Tracker.stale · Tracker.update(dt)

   Nobody else edits this file. If you need it to behave differently,
   ask the owner — that conversation is what your change register is made of.

   YOUR NUMBER: End-to-end latency (ms) and standstill jitter (mm) at your chosen filter setting
   ═════════════════════════════════════════════════════════════════ */
"use strict";

/* ── Sensor simulation ───────────────────────────────────────── */
const Sim = { noise:0.008, drop:0.03, beam:30 };
let gauss_spare = null;
function gauss(){
  if(gauss_spare!==null){ const v=gauss_spare; gauss_spare=null; return v; }
  let u=0,v=0; while(!u) u=Math.random(); v=Math.random();
  const m=Math.sqrt(-2*Math.log(u));
  gauss_spare = m*Math.sin(2*Math.PI*v);
  return m*Math.cos(2*Math.PI*v);
}
/** Model each RCWL-1601 as a cone facing +y, rotated by its mount angle. */
function simulateRanges(truth, sensors){
  return sensors.map(s=>{
    const dx = truth.x - s.x, dy = truth.y - s.y;
    const d = Math.hypot(dx,dy);
    const facing = (s.a||0) * Math.PI/180;              // 0 = straight out from wall
    const bearing = Math.atan2(dx, dy);                 // relative to +y
    if(Math.abs(bearing - facing) > Sim.beam*Math.PI/180) return null;  // outside beam
    if(d > 4.0 || d < 0.02) return null;                // out of sensor range
    if(Math.random() < Sim.drop) return null;           // no echo this ping
    const surface = d - AREA.bodyR;                     // echo comes off the body surface
    return Math.max(0.02, surface + gauss()*Sim.noise);
  });
}

/* ── Tracker: owns the filtered player position ──────────────── */
const Tracker = {
  src:"mouse", alpha:0.35,
  raw:null, pos:null, ranges:[], nSensors:0, res:0, hz:0,
  lastFrame:0, frames:0, hzT:0, stale:false,
  layout:"4lin",
  get sensors(){ return LAYOUTS[this.layout].s; },
  mouse:{x:AREA.w/2, y:1.3, has:false},
  live:{ ws:null, ranges:[], t:0 },

  update(dt){
    let measured = null;
    if(this.src === "mouse"){
      this.ranges = simulateRanges(this.mouse, this.sensors); // shown on the radar only
      measured = this.mouse.has ? {x:this.mouse.x, y:this.mouse.y} : null;
      this.nSensors = this.ranges.filter(r=>r!=null).length;
      this.res = 0; this.stale = false;
    } else if(this.src === "sim"){
      this.ranges = simulateRanges(this.mouse, this.sensors);
      const fix = solvePosition(this.ranges, this.sensors);
      this.nSensors = this.ranges.filter(r=>r!=null).length;
      if(fix){ measured = fix; this.res = fix.res; this.stale = false; }
      else { this.stale = true; }
    } else {
      const age = performance.now() - this.live.t;
      this.stale = age > 400 || !this.live.ranges.length;
      this.ranges = this.stale ? this.sensors.map(()=>null) : this.live.ranges;
      this.nSensors = this.ranges.filter(r=>r!=null).length;
      if(!this.stale){
        const fix = solvePosition(this.ranges, this.sensors);
        if(fix){ measured = fix; this.res = fix.res; } else { this.stale = true; }
      }
    }

    if(measured){
      this.raw = measured;
      const a = this.src === "mouse" ? 1 : this.alpha;
      if(!this.pos) this.pos = {x:measured.x, y:measured.y};
      else {
        // exponential moving average, frame-rate compensated
        const k = 1 - Math.pow(1-a, Math.min(3, dt*60));
        this.pos.x += (measured.x - this.pos.x)*k;
        this.pos.y += (measured.y - this.pos.y)*k;
      }
    }

    this.frames++; this.hzT += dt;
    if(this.hzT >= 0.5){ this.hz = this.frames/this.hzT; this.frames=0; this.hzT=0; }
  },

  connect(url){
    try{ if(this.live.ws) this.live.ws.close(); }catch(e){}
    $("#wsState").textContent = "connecting";
    const ws = new WebSocket(url);
    this.live.ws = ws;
    ws.onopen  = () => $("#wsState").textContent = "open";
    ws.onclose = () => $("#wsState").textContent = "closed";
    ws.onerror = () => $("#wsState").textContent = "error";
    ws.onmessage = ev => {
      try{
        const m = JSON.parse(ev.data);
        if(Array.isArray(m.ranges)){
          const off = (m.box|0) * (m.ranges.length);
          const out = this.live.ranges.length === this.sensors.length
            ? this.live.ranges.slice() : this.sensors.map(()=>null);
          m.ranges.forEach((v,i)=>{ const idx = m.box==null ? i : off+i;
            if(idx < out.length) out[idx] = (v==null? null : v/1000); });
          this.live.ranges = out;
        } else if(m.id != null){
          const out = this.live.ranges.length === this.sensors.length
            ? this.live.ranges.slice() : this.sensors.map(()=>null);
          out[m.id] = m.mm==null ? null : m.mm/1000;
          this.live.ranges = out;
        }
        this.live.t = performance.now();
      }catch(e){}
    };
  }
};
