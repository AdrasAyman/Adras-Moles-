/* ═════════════════════════════════════════════════════════════════
   MOLEFIELD · solver.js
   OWNER: PERSON 1
   SUBSYSTEM: Sensor fusion & calibration

   CONSUMES  ranges[] in metres (null = no echo), sensors[] geometry from LAYOUTS
   PROVIDES  solvePosition(ranges, sensors) -> {x, y, res, n} | null

   Nobody else edits this file. If you need it to behave differently,
   ask the owner — that conversation is what your change register is made of.

   YOUR NUMBER: Median position error (mm) and fix rate (%) across the play area, from tools/layout_bench.py
   ═════════════════════════════════════════════════════════════════ */
"use strict";

/* ── Multilateration ─────────────────────────────────────────── */
/** Least-squares trilateration: coarse grid, then gradient refine.
 *  Returns {x,y,res,n} or null when fewer than 2 sensors report. */
function solvePosition(ranges, sensors){
  const obs = [];
  for(let i=0;i<ranges.length;i++){
    if(ranges[i]==null) continue;
    obs.push({ s:sensors[i], d: ranges[i] + AREA.bodyR });   // back to body-centre distance
  }
  if(obs.length < 2) return null;
  const cost = (x,y) => {
    let c=0;
    for(const o of obs){ const e = Math.hypot(x-o.s.x, y-o.s.y) - o.d; c += e*e; }
    return c;
  };
  let bx=AREA.w/2, by=1.2, bc=Infinity;
  const G=26;
  for(let i=0;i<=G;i++) for(let j=0;j<=G;j++){
    const x = (i/G)*AREA.w, y = AREA.yVisTop + (j/G)*(AREA.yFar-AREA.yVisTop);
    const c = cost(x,y);
    if(c<bc){ bc=c; bx=x; by=y; }
  }
  let x=bx, y=by, step=0.06;
  for(let it=0; it<60; it++){
    let gx=0, gy=0;
    for(const o of obs){
      const dx=x-o.s.x, dy=y-o.s.y, d=Math.hypot(dx,dy)||1e-6, e=d-o.d;
      gx += 2*e*dx/d; gy += 2*e*dy/d;
    }
    x -= step*gx; y -= step*gy;
    x = Math.max(-0.3, Math.min(AREA.w+0.3, x));
    y = Math.max(0.05, Math.min(AREA.yFar+0.3, y));
    step *= 0.97;
  }
  return { x, y, res: Math.sqrt(cost(x,y)/obs.length), n: obs.length };
}
