# Ownership

Five people, five sets of files, no overlap. **You do not edit another
person's file.** If you need it to behave differently, ask the owner. Those
conversations are what your individual Change Register is made of.

Put real names in the table below and in each file header before week 3, and
don't swap after that — the individual marks in Sprints 1 and 2 ask you to
trace *your* subsystem from the raw requirement all the way to V3, and you
can't write that document about a subsystem you only touched for a fortnight.

| | Name | Owns | Subsystem |
|---|---|---|---|
| **1** | | `game/js/solver.js` | Sensor fusion & calibration |
| **2** | | `game/js/tracker.js` | Signal conditioning, sources & latency |
| **3** | | `game/js/game.js` | Game logic, levels & difficulty |
| **4** | | `game/js/safety.js`, `audio.js`, `render.js` | Safety supervisor & the whole human interface |
| **5** | | `game/index.html`, `js/core.js`, `js/ui.js`, `js/main.js`, `molefield.py`, `build_windows.bat` | Integration, bridge, packaging & test |

`js/core.js` is shared. It holds the play-area dimensions, the sensor layouts
and the level table — change it and everyone's code changes underneath them.
Person 5 holds the pen, but a change needs the whole team to agree.

---

## The number you defend

Every person needs one measurable thing, because Assessment 2 wants
mathematical modelling, simulation calibration and physical testing of *your*
subassembly. "I wrote the drawing code" is not a design review.

| | Your number | How you measure it |
|---|---|---|
| 1 | Median position error (mm) and fix rate (%) | `python tools/layout_bench.py` across layouts and noise levels |
| 2 | End-to-end latency (ms) and standstill jitter (mm) | Record with `--log`, compare `raw` against `pos` columns |
| 3 | Hit rate and median time-to-whack, per level | Playtest with 5+ people, log the sessions |
| 4 | Alarm latency from crossing 0.60 m (ms), false-alarm rate | Walk-in tests, timestamped against the log |
| 5 | Dropped frames over 10 minutes; clean-machine install success | `--log` frame gaps; install the exe on a PC that has never seen the project |

---

## Contracts

Four interfaces. As long as these hold, everyone can rebuild the inside of
their own file without breaking anyone else.

**1. Boxes → bridge** (UDP 4210, JSON) — frozen, your electrical team codes against it:
```json
{"box": 0, "t": 184213, "ranges": [1420, 1655], "batt": 5210}
```

**2. Bridge → game** (WebSocket 8765, JSON) — frozen:
```json
{"t": 184213, "ranges": [1420, 1655, null, 1390]}
```

**3. Solver → tracker** — person 1 hands person 2:
```js
solvePosition(ranges, sensors) -> {x, y, res, n} | null    // metres; null = no fix
```

**4. Tracker → everyone** — person 2 hands persons 3, 4 and 5:
```js
Tracker.pos    // {x, y} in metres, smoothed — or null before first fix
Tracker.raw    // {x, y} unfiltered, for comparison plots
Tracker.stale  // true when the fix is old or impossible; DO NOT trust pos
```

Anyone reading `Tracker.pos` must check `Tracker.stale` first. A cursor frozen
somewhere wrong is worse than no cursor, and during the stress test it will
be the difference between a graceful degrade and a demo that looks broken.

---

## Load order is a contract

`index.html` loads the modules in this order, and each file may use anything
loaded above it:

```
core → audio → solver → tracker → game → safety → render → ui → main
```

These are plain scripts, not ES modules, on purpose: they work when you
double-click `index.html` as well as when the bridge serves it, and they need
no build step. The cost is that a name defined in one file is visible
everywhere, so **prefix anything new with your subsystem** — `solverGrid`,
not `grid` — or you will collide with someone eventually.

Only `ui.js` and `main.js` run code at load time. Everything else just
defines things. Keep it that way and the order only has to hold at startup.

---

## Working rules

**One branch per person, named after the file you own.** Merge conflicts
inside a single file are the thing this whole structure exists to prevent, so
if you find yourself resolving one, someone edited a file they don't own.

**Integrate at a fixed weekly time**, not "when we're ready." Book the room.
Integration failures found in week 12 are how these projects die, and the
whole point of the module split is that integration should be boring.

**Run the harness before every merge.** From the project root:
```
node tools/harness.js
```
It loads all nine modules in order against a stub DOM, plays real frames, and
checks that the alarm still fires with the game stopped. If it fails, the
merge is not ready. It takes under a second, so there is no excuse.

**Keep your change register from week 1**, in the repo, next to your code.
Reconstructing it in week 8 from memory produces a visibly thin document, and
the rubric explicitly asks for an honest account of the knowledge gaps you
found during the V1-to-V2 transition. You can only write that if you wrote it
down at the time.

---

## What each person does first

1. **Solver** — run `tools/layout_bench.py` at several beam angles and pick the
   sensor layout on evidence. Tell the hardware people before they drill.
2. **Tracker** — record a log standing still, and another walking. You need
   jitter and latency numbers before you can argue for a filter.
3. **Game** — playtest the current dwell time with people who have not seen it.
   500 ms feels slow to the person who wrote it and fast to everyone else.
4. **Safety** — measure how long the alarm actually takes to fire from a
   walking start. The V2 note at the bottom of `safety.js` is your whole sprint.
5. **Integration** — get `build_windows.bat` producing an exe that runs on a
   laptop that has never had Python on it. Do this early; it is a requirement,
   not a nice-to-have, and it always takes longer than anyone expects.
