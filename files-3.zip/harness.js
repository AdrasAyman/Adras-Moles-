/* Loads every module in the real order against a stubbed DOM, then runs
   frames of actual gameplay. Catches undefined references and broken
   cross-module contracts that a syntax check cannot. */
const fs = require("fs"), vm = require("vm");

const files = ["core", "audio", "solver", "tracker", "game", "safety",
               "render", "ui", "main"];

function fakeCtx() {
  return new Proxy({}, {
    get: (t, k) => {
      if (k === "canvas") return { width: 900, height: 600 };
      if (["fillStyle","strokeStyle","lineWidth","globalAlpha","font",
           "textAlign","lineCap"].includes(k)) return "";
      return () => ({ addColorStop(){} });
    },
    set: () => true,
  });
}

const els = {};
function el(id) {
  if (els[id]) return els[id];
  return els[id] = {
    id, hidden: false, value: "ws://localhost:8765", textContent: "",
    className: "", dataset: {}, style: {},
    width: 900, height: 600,
    getContext: fakeCtx,
    getBoundingClientRect: () => ({ width: 900, height: 600, left: 0, top: 0 }),
    parentElement: { getBoundingClientRect: () => ({ width: 900, height: 600 }) },
    classList: { toggle(){}, remove(){}, add(){} },
    addEventListener(){}, setAttribute(){}, click(){},
    onclick: null,
  };
}

const sandbox = {
  console, Math, Date, JSON, performance: { now: () => Date.now() },
  URLSearchParams, Proxy, isNaN, parseInt, parseFloat,
  requestAnimationFrame: () => 0, setTimeout: () => 0, clearTimeout: () => 0,
  addEventListener: () => {},
  WebSocket: function () { this.close = () => {}; },
  location: { search: "", hostname: "localhost" },
  document: {
    querySelector: s => el(s),
    querySelectorAll: () => [],
    createElement: () => el("tmp"),
  },
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

for (const f of files) {
  const src = fs.readFileSync(`game/js/${f}.js`, "utf8");
  try {
    vm.runInContext(src, sandbox, { filename: `${f}.js` });
    console.log(`  loaded   ${f}.js`);
  } catch (e) {
    console.log(`  FAILED   ${f}.js  ->  ${e.message}`);
    process.exit(1);
  }
}

/* Top-level const/let in a classic script live in the shared global *lexical*
   environment, not on globalThis. That is exactly what makes this split work
   in a browser — but it means the harness has to ask from the inside. */
vm.runInContext(`globalThis.X = { solvePosition, LAYOUTS, G, Tracker, Safety,
  updateGame, resetRun, drawStage, drawRadar, updateHUD, buildHoles, Sim };`,
  sandbox, { filename: "export.js" });

// ── exercise the real cross-module paths ──────────────────────────────────
const S = sandbox.X;
console.log("\n  contracts:");
const fix = S.solvePosition([1.2, 1.1, 1.3, 1.5], S.LAYOUTS["4lin"].s);
console.log("    solver -> keys:", Object.keys(fix),
            "| x=" + fix.x.toFixed(3), "y=" + fix.y.toFixed(3));
console.log("    solver with 1 range ->", S.solvePosition([1.2, null, null, null],
  S.LAYOUTS["4lin"].s), "(must be null)");
if (S.solvePosition([1.2, null, null, null], S.LAYOUTS["4lin"].s) !== null) process.exit(1);

S.resetRun();
console.log("    resetRun -> phase", S.G.phase, "| holes", S.G.holes.length);

// simulate a body parked on a mole until it is whacked
let frames = 0, hits = 0;
const start = S.G.score;
S.Tracker.mouse.has = true;
for (let i = 0; i < 1200; i++) {
  const m = S.G.moles.find(x => !x.dead && x.state !== "sink");
  if (m) { S.Tracker.mouse.x = m.hole.x; S.Tracker.mouse.y = m.hole.y; }
  S.Tracker.update(1 / 60);
  S.Safety.update(1 / 60);
  if (S.G.phase === "play") S.updateGame(1 / 60);
  S.drawStage(1 / 60);
  S.drawRadar();
  S.updateHUD();
  frames++;
  if (S.G.score > start) hits = 1;
  if (S.G.phase !== "play") break;
}
console.log(`    ran ${frames} frames, phase now "${S.G.phase}", score ${S.G.score}`);
if (!hits) { console.log("    FAIL: never scored — dwell-to-whack is broken"); process.exit(1); }

// safety supervisor must fire on its own, with the game not playing
S.G.phase = "over";
S.Tracker.pos = { x: 0.75, y: 0.30 };
S.Tracker.stale = false;
S.Safety.update(0.5);
console.log(`    dead-zone alarm outside gameplay: ${S.Safety.active} (must be true)`);
if (!S.Safety.active) process.exit(1);
S.Tracker.pos = { x: 0.75, y: 1.30 };
S.Safety.update(0.5);
console.log(`    releases when clear: ${!S.Safety.active} (must be true)`);
if (S.Safety.active) process.exit(1);

console.log("\n  ALL MODULE CONTRACTS HOLD\n");
